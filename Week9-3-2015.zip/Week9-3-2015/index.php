<?php session_start(); ?>
<?php 
	include ("includes/connection.php");
	if(!isset($_SESSION['username'])) {
		header("location: login.php");
	}
?>
<?php include("includes/header.php"); ?>

		<div class="container">
			<div class="row text-center">
				<h1>Welcome <?php echo $_SESSION['username']; ?> !</h1>
			</div>
			<div class="row">
				<table class="table table-striped table-bordered">
				<th>ID</th>
				<th>Username</th>
				<?php
					$a = new userLogin;
					$results = $a->getUsers();
					foreach ($results as $key) {
						echo "tr";
						echo $key ["USERNAME"];
						echo("/tr")
					}
				?>
				</table>
			</div>
		</div>


<?php include("includes/footer.php"); ?>