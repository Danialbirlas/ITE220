<?php 
	session_start();
	include ("includes/connection.php");
	$connection = new userLogin;
	$result = $connection->getUser($_POST['myusername'],$_POST['mypassword']);

	if($result == 'true') {
		$_SESSION['username'] = $_POST['myusername'];
		header("location: index.php");
	}else {
		// redirect to login-error.php
		header("location: login-error.php");
	}
?>