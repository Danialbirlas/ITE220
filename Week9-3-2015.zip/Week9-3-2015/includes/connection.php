<?php

	class dbConn {
		public $conn;
		public function __construct(){
			include 'config.php';
			// Connect to server and select database.
			$this->conn = new PDO('mysql:host='.$host.';dbname='.$db_name.';charset=utf8', $username, $password);
			$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
	};

	class userLogin extends dbConn {
		public function getUsers() {
			include 'config.php';
			try {
				$db = new dbConn;
				$err = '';
				$stmt = $db->conn->prepare("SELECT * FROM USERS");
				$stmt->execute();

				// Gets query result
				$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
			}
			catch (PDOException $e) {
				$err = "Error: " . $e->getMessage();
			}
			//Determines returned value ('true' or error code)
			if ($err == '' && $results !=null) {
				$success = $results;
			}
			else {
				$success = $err;
			};

			return $success;
		}

		
		public function getUser($u, $p) {
			include 'config.php';
			try {
				$db = new dbConn;
				$err = '';
				$stmt = $db->conn->prepare("SELECT * FROM USERS  WHERE USERNAME = :username and PASSWORD = :password ;");
				$stmt->bindParam(':username', $u);
				$stmt->bindParam(':password', md5($p));
				$stmt->execute();

				// Gets query result
				$results = $stmt->fetch(PDO::FETCH_ASSOC);
			}
			catch (PDOException $e) {
				$err = "Error: " . $e->getMessage();
			}
			//Determines returned value ('true' or error code)
			if ($err == '' && $results !=null) {
				$success = 'true';
			}
			else {
				$success = $err;
			};

			return $success;
		}

		public function insertUser($u, $p) {
			include 'config.php';
			try {
				$db = new dbConn;
				$err = '';
				// prepare sql and bind parameters
				$stmt = $db->conn->prepare("INSERT INTO USERS (USERNAME, PASSWORD) VALUES(:username, :password)");
				$stmt->bindParam(':username',$u);
				$stmt->bindParam(':password', md5($p));
				$stmt->execute();
			}
			catch (PDOException $e) {
				$err = "Error: " . $e->getMessage();
			}
			//Determines returned value ('true' or error code)
			if ($err == '') {
				$success = 'true';
			}
			else {
				$success = $err;
			};

			return $success;
		}
	};
?>
