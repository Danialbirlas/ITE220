<?php
	$host = "localhost:3306"; 
	// Host name
	$username = "root"; 
	// Mysql username
	$password = ""; 
	// Mysql password
	$db_name = "LOGIN_SYSTEM"; 
	// Database name
?>