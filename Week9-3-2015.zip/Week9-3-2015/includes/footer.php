<footer class="footer">
  <div class="container">
  	<div class="col-md-6">
    	<p class="text-muted">Mintra Ruensuk. 1994, 2016. All rights reserved.</p>
    </div>
    <div class="col-md-6">
    	<p class="text-muted text-right">Want support?: <a href="mailto:mintra.ruensuk@stamford.edu">mintra.ruensuk@stamford.edu</a></p>
    </div>
  </div>
</footer>
</body>
</html>