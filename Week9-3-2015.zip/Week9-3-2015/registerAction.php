<?php
	include ("includes/connection.php");
	$username = $_POST['myusername'];
	//echo $username;
	$password = $_POST['mypassword'];
	//echo $password;
	$a = new userLogin;
	$result = $a->insertUser($username, $password);
	if($result == 'true') {
		header("location: index.php");
	}else {
		echo "Eroor is $result";
	}

?>	