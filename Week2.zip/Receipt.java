
public class Receipt {
	public static void main(String[] args) {
	// I calculated the total owed, assuming 5% tax / 15% tip
		int subtotal = 48 + 30 + 40;
		double tax = subtotal * .05;
		double tip = subtotal * .15;
		double total = subtotal + tax + tip;
		
		System.out.println("Subtotal: " + subtotal);
		System.out.println("Tax; " + tax);
		System.out.println("Tip; " + tip);
		System.out.println("Total; " + total);
		
		
		
	}

}
