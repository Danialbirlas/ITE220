
public class GradeResult {
	public static void main(String[] args) {
		String ENG="ENG102 College English II  A";
		String ITE="ITE101 Introduction to Information Technology B";
		String ITE120="ITE120 Web Development I  C";
		String MIS="MIS103 Computer Applications    B";
		String POL="POL104 Issues in Internation Human Rights B+";
		
 		double GPA=(3+4+2+3+3.5)/5;
		System.out.println(ENG);
		System.out.println(ITE);
		System.out.println(ITE120);
		System.out.println(MIS);
		System.out.println(POL);
		System.out.println("GPA is " + GPA);
			
		
	}

}
