var msg ="Srgn up to recieve our newsletter for 10% off.";

function updateMessage() {
	var el = document.getElementById("heading-message");
	el.textContent = msg; 
}
//call the update message funtion 
updateMessage();